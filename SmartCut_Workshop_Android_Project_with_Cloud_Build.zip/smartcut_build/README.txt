SMARTCUT WORKSHOP — ANDROID PROJECT

This project includes a GitHub Actions workflow to build an installable debug APK online.

BUILD THE APK ONLINE (no Android Studio required):
1. On GitHub.com, create/sign in to a free account.
2. Create a new repository (for example: smartcut-workshop). Public or private is fine.
3. Upload the contents of this ZIP to the repository. Upload the files/folders themselves, including the hidden .github folder. If GitHub's browser upload makes hidden folders difficult, use a computer or GitHub's web editor to add .github/workflows/build-apk.yml.
4. Open the repository's Actions tab.
5. Select “Build SmartCut Workshop APK” and press “Run workflow” (or push/upload to main/master to trigger it).
6. Wait for the run to finish successfully. Open the completed run and download the artifact named “SmartCut-Workshop-APK”.
7. Extract the downloaded artifact ZIP; it contains app-debug.apk. Transfer that APK to your Android phone and open it to install. If Android asks, allow installing unknown apps for the app you used to open it.

IMPORTANT:
- The APK is a debug build, not a Play Store release.
- Android may show a security warning because it is installed outside the Play Store.
- Keep a backup of your project data using the app's backup/export feature.
- The current app includes project storage, a cutting-list text parser, edge-banding calculations, rough sheet-area estimates, and exports. It does NOT yet provide true optimized 2D sheet nesting/cutting diagrams.

ALTERNATIVE:
Open the project in Android Studio on a computer and choose Build > Build APK(s).
